//
//  ViewController.swift
//  Project1-BasicCalculator
//
//  Created by user149827 on 2/24/19.
//  Copyright © 2019 Thomas Bischoff. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    // Display Output for the Calculator
    @IBOutlet weak var lblOutput: UILabel!
    // Number Currently on Screen
    var displayedNumber:Double = 0
    // Previously Entered Number
    var firstNumber:Double = 0
    // Mark if the Calculator is Curretnly Doing an Operation
    var runningOperation:Bool = false
    // Current Operation Being Performed by the Calculator
    var currentOperation:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    // Gets the Numeric Inputs that the User Enters
    @IBAction func btnNumberInput(_ sender: UIButton)
    {
        // Check to See if the User is Performing a Mathmatical Operation
        if runningOperation
        {
            // Set the Displayed Number to Be Zero
            lblOutput.text = "0"
            // Update the Current Number to be Zero
            displayedNumber = 0
            // Set the Calculator to Stop Running the Operation
            runningOperation = false
        }
        // Create a Variable to Hold the User's Input
        let userInput = sender.currentTitle
        // Create a Variable to Hold the Current Displayed Number
        let currentDisplay = lblOutput.text
        // Check to See if that Variable is a Decimal Point
        if userInput == "."
        {
            // Check to See that the Current Display Does Not Currently Have a Decimal Point
            if !currentDisplay!.contains(".")
            {
                // Append the Decimal Point to the Display
                lblOutput.text = lblOutput.text! + userInput!
                // Update the Current Number
                displayedNumber = Double (lblOutput.text!)!
            }
        }
        // Otherwise
        else
        {
            // Check if the First Number is Zero
            if currentDisplay!.first == "0"
            {
                // Check to See if the Length is Greater Than One
                if currentDisplay!.count > 1
                {
                    // Append the Number to the Display
                    lblOutput.text = lblOutput.text! + userInput!
                    // Update the Current Number
                    displayedNumber = Double (lblOutput.text!)!
                }
                // Otherwise
                else
                {
                    // Replace the Zero with the Entered Number
                    lblOutput.text = userInput!
                    // Update the Current Number
                    displayedNumber = Double (lblOutput.text!)!
                }
            }
            // Otherwise
            else
            {
                // Append the Number to the Display
                lblOutput.text = lblOutput.text! + userInput!
                // Update the Current Number
                displayedNumber = Double (lblOutput.text!)!
            }
        }
    }
    
    // Recieves Inputs for Carrying Out Operations
    @IBAction func btnFunctionInputs(_ sender: UIButton)
    {
        // Get the User's Input
        let userInput = sender.currentTitle
        // Get the Current Display
        let currentDisplay = lblOutput.text
        // Check to See that the Display is Not Empty and that the Didn't Click Equal or Clear
        if currentDisplay != "" && (userInput != "AC" && userInput != "=")
        {
            // Check that the Input is Not the Percent Sign
            if userInput != "%"
            {
                // Set the Current Operation to Be Equal to the Users Input
                currentOperation = userInput!
                // Save the Current Number Entered as the Original Number
                firstNumber = displayedNumber
            }
            // Otherwise
            else
            {
                //Set the Current Input to be Equal to the User's Input
                currentOperation = "XX%"
                // Save the Number as a Percentage
                firstNumber = displayedNumber / 100
            }
        }
        // Check if the User Clicked the Equal Button
        else if userInput == "="
        {
            // Check if the Current Operation Being Run is Addition
            if currentOperation == "+"
            {
                // Display the Answer to the User
                lblOutput.text = String(addition(_num1: firstNumber, _num2: displayedNumber))
            }
            // Check if the Current Operation Being Run is Subtraction
            else if currentOperation == "-"
            {
                // Display the Answer to the User
                lblOutput.text = String(subtraction(_num1: firstNumber, _num2: displayedNumber))
            }
            // Check if the Current Operation Being Run is Multiplication or Percentage
            else if currentOperation == "X" || currentOperation == "XX%"
            {
                // Display the Answer to the User
                lblOutput.text = String(multiplication(_num1: firstNumber, _num2: displayedNumber))
            }
            // Check if the Current Operation Being Run is Division
            else if currentOperation == "/"
            {
                // Check if the Displayed Number is Zero
                if displayedNumber == 0
                {
                    // Display Error Message to User
                    lblOutput.text = "ERROR"
                }
                // Otherwise
                else
                {
                    // Display the Answer to the User
                    lblOutput.text = String(division(_num1: firstNumber, _num2: displayedNumber))
                }
            }
        }
        // Check if the User Clicked the Clear Button
        else if userInput == "AC"
        {
            // Reset the Displayed Number to be Zero
            lblOutput.text = "0"
            // Set the Current Number to Be Zero
            displayedNumber = 0
            // Set the First Number to Be Zero
            firstNumber = 0
            // Set the Current Operation to Be Blank
            currentOperation = ""
        }
        // Mark that the Calculator Is Running an Operation
        runningOperation = true
    }
    
    // Recieves +/- and % Button Inputs
    @IBAction func btnSpecial(_ sender: UIButton)
    {
        // Get the User's Input
        let userInput = sender.currentTitle
        // Get the Current Display
        var currentDisplay = lblOutput.text
        // Check if the User Clicked the +/- Button
        if userInput == "+/-"
        {
            // Check that the Number is Not Zero
            if currentDisplay != "0"
            {
                // Check if the Number is Negative
                if currentDisplay!.hasPrefix("-")
                {
                    // Remove the Negative Sign From the Displayed Number
                    currentDisplay!.remove(at: currentDisplay!.startIndex)
                    // Update the Displayed Number
                    lblOutput.text = currentDisplay
                    // Set the Current Number to be the Same as the Display
                    displayedNumber = Double(lblOutput.text!)!
                }
                // Otherwise
                else
                {
                    // Add the Negative Sign in Front of the Displayed Number
                    lblOutput.text = "-" + lblOutput.text!
                    // Set the Current Number to Match the Displayed Number
                    displayedNumber = Double(lblOutput.text!)!
                }
            }
        }
        // Otherwise
        else
        {
            // Update the Current Number to be a Percentage
            displayedNumber = displayedNumber / 100
            // Display the Number
            lblOutput.text = String(displayedNumber)
        }
    }
    
    // Peform the Process of Addition
    func addition(_num1:Double, _num2:Double) -> Double
    {
        // Create a Value to Hold the Sum of the Two Numbers
        let answer = _num1 + _num2
        // Return the Answer
        return answer
    }
    
    // Perform the Process of Subtraction
    func subtraction(_num1:Double, _num2:Double) -> Double
    {
        // Create a Value to Hold the Remaining Value of the Two Numbers
        let answer = _num1 - _num2
        // Return the Answer
        return answer
    }
    
    // Perform the Process of Multiplication
    func multiplication(_num1:Double, _num2:Double) -> Double
    {
        // Create a Value to Hold the Product of the Two Numbers
        let answer = _num1 * _num2
        // Return the Answer
        return answer
    }
    
    // Perform the Process of Division
    func division(_num1:Double, _num2:Double) -> Double
    {
        // Create a Value to Hold the Result of the Division
        let answer = _num1 / _num2
        // Return the Answer
        return answer
    }
}

